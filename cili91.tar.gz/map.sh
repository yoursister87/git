#! /bin/bash
sqlhash="use ssbc; SELECT info_hash FROM search_hash;"
echo "please wait data getting!"
rm ./www/map.csv -f
mysql -h 127.0.0.1  -uroot -p --default-character-set="utf8" -e "$sqlhash" -N >>./www/map.csv
echo "data has get over"
python ./map.py
