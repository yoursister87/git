#coding: utf8
import re
import time
import datetime
import sys
import urllib

from django.http.response import HttpResponse
from django.http import Http404
from django.views.decorators.cache import cache_page
from django.shortcuts import render, redirect
from DjangoCaptcha import Captcha
from django.db.models import Sum

from lib import politics
import workers.metautils
import workers.magtobt
from top.models import KeywordLog, Newkey, Newhash
from search.models import StatusReport, RecKeywords, Hash
from dmca.models import Hashlog

re_punctuations = re.compile(
    u"。|，|,|！|…|!|《|》|<|>|\"|'|:|：|？|\?|、|\||“|”|‘|’|；|—|（|）|·|\(|\)|　|\.|【|】|『|』|@|&|%|\^|\*|\+|\||<|>|~|`|\[|\]")


#@cache_page(600)
def index(request):
    d = {'index':index}
    #d['keyword_logs'] = Newkey.objects
    report = StatusReport.objects.all()
    tt = report.aggregate(Sum('new_hashes'))
    d['total_hash'] = tt['new_hashes__sum']
    td = report.order_by('-id')[:1].aggregate(Sum('new_hashes'))
    d['today_hash'] = td['new_hashes__sum']
    d['reclist'] = RecKeywords.objects.order_by('-order')
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","EN")
    d['lang']=lang
    return render(request, 'index.html', d)


#@cache_page(600)
def tags(request, page=None):
    if not page:
         page = 1
    d = {'tags':tags}
    try:
         d['page'] = int(page)
    except:
         d['page'] = 1
    d['ps'] = 100
    d['start'] = d['ps']*(d['page']-1)
    d['last'] = d['ps']*d['page']
    d['list'] = Newkey.objects.order_by('-id')[d['start']:d['last']]
    w = 10
    total = Newkey.objects.count()
    d['page_max'] = total / d['ps'] if total % d['ps'] == 0 else total/d['ps'] + 1
    d['prev_pages'] = range( max(d['page']-w+min(int(w/2), d['page_max']-d['page']),1), d['page'])
    d['next_pages'] = range( d['page']+1, int(min(d['page_max']+1, max(d['page']-w/2,1) + w )) )
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d['lang']=lang
    return render(request, 'tags.html', d)


#@cache_page(3600*24)
def hash(request, h):
    try:
        res = Hash.objects.list_with_files([h])
        j = res[0]
    except:
        raise Http404(sys.exc_info()[1])
    d = {'info': j} 
    d['keywords'] = list(set(re_punctuations.sub(u' ', d['info']['name']).split()))
    if 'files' in d['info']:
        d['info']['files'] = [y for y in d['info']['files'] if not y['path'].startswith(u'_')]
        d['info']['files'].sort(key=lambda x:x['length'], reverse=True)
    d['magnet_url'] = 'magnet:?xt=urn:btih:' + d['info']['info_hash'] + '&' + urllib.urlencode({'dn':d['info']['name'].encode('utf8')})
    d['td_url'] = workers.magtobt.Url2Thunder('magnet:?xt=urn:btih:' + d['info']['info_hash'])
    d['bt_url'] = workers.magtobt.magnet_to_torrent('magnet:?xt=urn:btih:' + d['info']['info_hash'])
    d['download_url'] = 'http://www.haosou.com/s?' + urllib.urlencode({'ie':'utf-8', 'src': 'btzhizhu', 'q': d['info']['name'].encode('utf8')})
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d['lang']=lang
    try:
        ua = request.META['HTTP_USER_AGENT']
    except KeyError:
        ua = 'unknown'
    if 'Googlebot' in ua:
        spd = 1
    elif 'spider' in ua:
        spd = 1
    elif 'HaosouSpider' in ua:
        spd = 1
    else:
        spd = 0
    if spd == 0 and lang =="CN" or lang == "HK":
         hashs = d['info']['info_hash']
         ip = request.META.get('HTTP_X_FORWARDED_FOR')
         if not ip: 
             try:
                 ip = request.META.get('HTTP_X_REAL_IP', '') 
             except:
                 ip = "unknow"
         Newhash.objects.create(info_hash=hashs, ip=ip)
    d['spiderv']= spd
    return render(request, 'info.html', d)


#@cache_page(1800)
def search(request, keyword=None, p=None):
    if not keyword:
        return redirect('/')
    if politics.is_sensitive(keyword):
        return redirect('/?' + urllib.urlencode({'notallow': keyword.encode('utf8')}))
    d = {'keyword': keyword}
    d['words'] = list(set(re_punctuations.sub(u' ', d['keyword']).split()))
    try:
        d['p'] = int(p or request.GET.get('p'))
    except:
        d['p'] = 1
    d['category'] = request.GET.get('c', '')
    d['sort'] = request.GET.get('s', 'default')
    d['ps'] = 10
    d['offset'] = d['ps']*(d['p']-1)
    res = Hash.objects.search(keyword, d['offset'], d['ps'], d['category'], d['sort'])
    d.update(res)
    # Fill info
    ids = [str(x['id']) for x in d['result']['items']]
    if ids:
        items = Hash.objects.list_with_files(ids)
        for x in d['result']['items']:
            for y in items:
                if x['id'] == y['id']:
                    x.update(y)
                    x['magnet_url'] = 'magnet:?xt=urn:btih:' + x['info_hash'] + '&' + urllib.urlencode({'dn':x['name'].encode('utf8')})
                    x['td_url'] = workers.magtobt.Url2Thunder('magnet:?xt=urn:btih:' + x['info_hash'])
                    x['bt_url'] = workers.magtobt.magnet_to_torrent('magnet:?xt=urn:btih:' + x['info_hash'])
                    x['maybe_fake'] = x['name'].endswith(u'.rar') or u'BTtiantang.com' in x['name'] or u'liangzijie' in x['name']
                    if 'files' in x:
                        x['files'] = [z for z in x['files'] if not z['path'].startswith(u'_')][:3]
                        x['files'].sort(key=lambda x:x['length'], reverse=True)
                    else:
                        x['files'] = [{'path': x['name'], 'length': x['length']}]
    # pagination
    w = 10
    total = int(d['result']['meta']['total_found'])
    d['page_max'] = total / d['ps'] if total % d['ps'] == 0 else total/d['ps'] + 1
    d['prev_pages'] = range( max(d['p']-w+min(int(w/2), d['page_max']-d['p']),1), d['p'])
    d['next_pages'] = range( d['p']+1, int(min(d['page_max']+1, max(d['p']-w/2,1) + w )) )
    d['sort_navs'] = [
        {'name': 'sort_default', 'value': 'default'},
        {'name': 'sort_time', 'value': 'time'},
        {'name': 'sort_length', 'value': 'size'},
        {'name': 'sort_relavance', 'value': 'rela'},
    ]
    d['cats_navs'] = [{'name': '全部', 'num': total, 'value': ''}]
    d['keyword_logs'] = Newkey.objects
    for x in d['cats']['items']:
        v = workers.metautils.get_label_by_crc32(x['category'])
        d['cats_navs'].append({'value': v, 'name': workers.metautils.get_label(v), 'num': x['num']})
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d['lang']=lang
    try:
        ua = request.META['HTTP_USER_AGENT']
    except KeyError:
        ua = 'unknown'
    if 'Googlebot' in ua:
        spd = 1
    elif 'spider' in ua:
        spd = 1
    elif 'HaosouSpider' in ua:
        spd = 1
    else:
        spd = 0
    if spd == 0:
        try:
           vp = int(p or request.GET.get('p'))
        except:
           vp=1
        if vp==1:
           ip = request.META.get('HTTP_X_FORWARDED_FOR')
           if not ip: 
               try:
                   ip = request.META.get('HTTP_X_REAL_IP', '') 
               except:
                   ip = "unknow"
           utcnow = datetime.datetime.utcnow()
           keywords = keyword.strip()[:100]
           if total != 0:
               if (len(keywords) >= 2) and (len(keywords) <= 20) and lang == "CN" or lang =="HK":
                  if '/' not in keywords:
                      KeywordLog.objects.create(keyword=keywords, ip=ip)
                      oldkeyword = Newkey.objects.filter(keyword__iexact=keywords).values()
                      if oldkeyword:
                          Newkey.objects.filter(keyword=keywords).update(log_time=utcnow)
                      else:
                          Newkey.objects.create(keyword=keywords) 
    d['spiderv']= spd
    return render(request, 'list.html', d)


@cache_page(1800)
def rss(request, keyword=None, p=None):
    if not keyword:
        return redirect('/')
    if politics.is_sensitive(keyword):
        return redirect('/?' + urllib.urlencode({'notallow': keyword.encode('utf8')}))
    d = {'keyword': keyword}
    d['words'] = list(set(re_punctuations.sub(u' ', d['keyword']).split()))
    try:
        d['p'] = int(p or request.GET.get('p'))
    except:
        d['p'] = 1
    d['category'] = request.GET.get('c', '')
    d['sort'] = request.GET.get('s', 'time')
    d['ps'] = 10
    d['offset'] = d['ps']*(d['p']-1)
    res = Hash.objects.search(keyword, d['offset'], d['ps'], d['category'], d['sort'])
    d.update(res)
    # Fill info
    ids = [str(x['id']) for x in d['result']['items']]
    if ids:
        items = Hash.objects.list_with_files(ids)
        for x in d['result']['items']:
            for y in items:
                if x['id'] == y['id']:
                    x.update(y)
                    x['magnet_url'] = 'magnet:?xt=urn:btih:' + x['info_hash'] + '&' + urllib.urlencode({'dn':x['name'].encode('utf8')})
                    x['td_url'] = workers.magtobt.Url2Thunder('magnet:?xt=urn:btih:' + x['info_hash'])
                    x['bt_url'] = workers.magtobt.magnet_to_torrent('magnet:?xt=urn:btih:' + x['info_hash'])
                    x['maybe_fake'] = x['name'].endswith(u'.rar') or u'BTtiantang.com' in x['name'] or u'liangzijie' in x['name']
                    if 'files' in x:
                        x['files'] = [z for z in x['files'] if not z['path'].startswith(u'_')][:3]
                        x['files'].sort(key=lambda x:x['length'], reverse=True)
                    else:
                        x['files'] = [{'path': x['name'], 'length': x['length']}]
    # pagination
    w = 10
    total = int(d['result']['meta']['total_found'])
    d['page_max'] = total / d['ps'] if total % d['ps'] == 0 else total/d['ps'] + 1
    d['prev_pages'] = range( max(d['p']-w+min(int(w/2), d['page_max']-d['p']),1), d['p'])
    d['next_pages'] = range( d['p']+1, int(min(d['page_max']+1, max(d['p']-w/2,1) + w )) )
    d['sort_navs'] = [
        {'name': '创建时间', 'value': 'time'},
        {'name': '文件大小', 'value': 'size'},
        {'name': '相关度', 'value': 'rela'},
    ]
    d['cats_navs'] = [{'name': '全部', 'num': total, 'value': ''}]
    for x in d['cats']['items']:
        v = workers.metautils.get_label_by_crc32(x['category'])
        d['cats_navs'].append({'value': v, 'name': workers.metautils.get_label(v), 'num': x['num']})
        
    return render(request, 'rss.html', d, content_type = "application/xml")	


@cache_page(1800)
def map(request, keyword=None, p=None):
    if not keyword:
        return redirect('/')
    if politics.is_sensitive(keyword):
        return redirect('/?' + urllib.urlencode({'notallow': keyword.encode('utf8')}))
    d = {'keyword': keyword}
    d['words'] = list(set(re_punctuations.sub(u' ', d['keyword']).split()))
    try:
        d['p'] = int(p or request.GET.get('p'))
    except:
        d['p'] = 1
    d['category'] = request.GET.get('c', '')
    d['sort'] = request.GET.get('s', 'time')
    d['ps'] = 100
    d['offset'] = d['ps']*(d['p']-1)
    res = Hash.objects.search(keyword, d['offset'], d['ps'], d['category'], d['sort'])
    d.update(res)
    # Fill info
    ids = [str(x['id']) for x in d['result']['items']]
    if ids:
        items = Hash.objects.list_with_files(ids)
        for x in d['result']['items']:
            for y in items:
                if x['id'] == y['id']:
                    x.update(y)
                    x['magnet_url'] = 'magnet:?xt=urn:btih:' + x['info_hash'] + '&' + urllib.urlencode({'dn':x['name'].encode('utf8')})
                    x['td_url'] = workers.magtobt.Url2Thunder('magnet:?xt=urn:btih:' + x['info_hash'])
                    x['bt_url'] = workers.magtobt.magnet_to_torrent('magnet:?xt=urn:btih:' + x['info_hash'])
                    x['maybe_fake'] = x['name'].endswith(u'.rar') or u'BTtiantang.com' in x['name'] or u'liangzijie' in x['name']
                    if 'files' in x:
                        x['files'] = [z for z in x['files'] if not z['path'].startswith(u'_')][:3]
                        x['files'].sort(key=lambda x:x['length'], reverse=True)
                    else:
                        x['files'] = [{'path': x['name'], 'length': x['length']}]
    # pagination
    w = 10
    total = int(d['result']['meta']['total_found'])
    d['page_max'] = total / d['ps'] if total % d['ps'] == 0 else total/d['ps'] + 1
    d['prev_pages'] = range( max(d['p']-w+min(int(w/2), d['page_max']-d['p']),1), d['p'])
    d['next_pages'] = range( d['p']+1, int(min(d['page_max']+1, max(d['p']-w/2,1) + w )) )
    d['sort_navs'] = [
        {'name': '创建时间', 'value': 'time'},
        {'name': '文件大小', 'value': 'size'},
        {'name': '相关度', 'value': 'rela'},
    ]
    d['cats_navs'] = [{'name': '全部', 'num': total, 'value': ''}]
    for x in d['cats']['items']:
        v = workers.metautils.get_label_by_crc32(x['category'])
        d['cats_navs'].append({'value': v, 'name': workers.metautils.get_label(v), 'num': x['num']})
        
    return render(request, 'map.html', d, content_type = "application/xml")	
	
	
def hash_old(request, h):
    return redirect('/hash/' + h +'.html', permanent=True)


def search_old(request, kw, p):
    return redirect('list', kw, p)


@cache_page(3600*2)
def xunlei(request):
    return render(request, 'xunlei.html', {})

@cache_page(3600*2)
def play(request):
    d = {'play':play}
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d['lang']=lang
    return render(request, 'play.html', d)


@cache_page(3600*2)
def about(request):
    d = {'about':about}
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d['lang']=lang
    return render(request, 'about.html', d)


@cache_page(3600*2)
def mobile(request):
    d = {'mobile':mobile}
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d['lang']=lang
    return render(request, 'mobile.html', d)


@cache_page(600)
def rm_maglink(request, h):
    try:
        res = Hash.objects.list_with_files([h])
        j = res[0]
    except:
        raise Http404(sys.exc_info()[1])
    d = {'info': j} 
    d['keywords'] = list(set(re_punctuations.sub(u' ', d['info']['name']).split()))
    if 'files' in d['info']:
        d['info']['files'] = [y for y in d['info']['files'] if not y['path'].startswith(u'_')]
        d['info']['files'].sort(key=lambda x:x['length'], reverse=True)
    _code = request.GET.get('code')
    if not _code:
        ca = Captcha(request)
    if True:
        ip = request.META.get('HTTP_X_FORWARDED_FOR')
        if not ip:
            try:
                ip = request.META.get('HTTP_X_REAL_IP', '')
            except:
                ip = "unknow"
        hashs = d['info']['info_hash']
        Hashlog.objects.create(info_hash=hashs, ip=ip)
        Hash.objects.filter(info_hash=h).update(classified=True)
        return HttpResponse('''Delete Success
<meta http-equiv="refresh" content="2;url= /wiki/%s.html ">''' % d['info']['info_hash'])
    else:
        return HttpResponse('''Verification code error
<meta http-equiv="refresh" content="2;url= /rm_maglink/%s ">''' % d['info']['info_hash'])

def code(request):
    ca =  Captcha(request)
    ca.words = ['hello','world','helloworld']
    ca.type = 'number'
    return ca.display()
