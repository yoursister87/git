#coding: utf8
import datetime
import re
from django import template
from django.utils.html import escape
from django.utils.safestring import mark_safe
from base64 import *
import workers.metautils

register = template.Library()
lang={
"CN":{
    "title":u'磁力链接_种子搜索神器',
    "searchtxt":u'世界这么大，我想搜搜看......',
    "magurl":u'磁力搜索',
    "headtip1":u'磁力搜索',
    "headtip2":u'标签',
    "headtip3":u'排行',
    "foottip1":u'移动版',
    "foottip2":u'在线播放',
    "foottip3":u'关于',
    "sort_default":u'默认排序',
    "sort_time":u'创建时间',
    "sort_length":u'文件大小',
    "sort_relavance":u'相关度',
    "search":u'搜 索',
    "create_time":u'创建时间：',
    "filelength":u'文件大小：',
    "downloads":u'下载热度：',
    "last_seen":u'最近下载：',
    "total_found":u'共找到',
    "about":u'条关于',
    "result":u'的结果，耗时',
    "time":u'创建时间',
    "lastdown":u'最近下载',
    "download_count":u'下载热度',
    "files_size":u'文件大小',
    "files":u'文件数量',
    "filetype":u'文件类型',
    "thunder":u'迅雷链接',
    "magnet":u'磁力链接',
    "seed":u'种子链接',
    "relavance_url":u'相关链接',
    "filelist":u'文件列表',
    "tips":u'友情提示',
    "mail_tip":u'投诉邮箱：',
    "interest":u'大家对这些感兴趣',
    "interest_text":u'亲，你造吗？将网页分享给您的基友，下载的人越多速度越快哦！',
    "video": u'视频',
    "image": u'图片',
    "document": u'文档',
    "music": u'音乐',
    "package": u'压缩',
    "software": u'软件',
    "other":u'其他',
    "toptip1":u'总排行',
    "toptip2":u'月排行',
    "toptip3":u'周排行',
    "toptip4":u'日排行',
    "toptip5":u'最新收录',
},
"HK":{
    "title":u'Ciliss - 磁力搜尋',
    "searchtxt":u'世界這麼大，我想搜搜看......',
    "magurl":u'磁力搜尋',
    "headtip1":u'磁力搜尋',
    "headtip2":u'標籤',
    "headtip3":u'排行',
    "foottip1":u'移動版',
    "foottip2":u'線上播放',
    "foottip3":u'關於',
    "sort_default":u'默認排序',
    "sort_time":u'收錄時間',
    "sort_length":u'文件大小',
    "sort_relavance":u'相關性',
    "search":u'搜 尋',
    "create_time":u'創建時間：',
    "filelength":u'文件大小：',
    "downloads":u'下載熱度：',
    "last_seen":u'最近下載：',
    "total_found":u'共找到',
    "about":u'條關於',
    "result":u'的結果，耗時',
    "time":u'創建時間',
    "lastdown":u'最近下載',
    "download_count":u'下載熱度',
    "files_size":u'文件大小',
    "files":u'文件數量',
    "filetype":u'文件類型',
    "thunder":u'迅雷鏈接',
    "magnet":u'磁力鏈接',
    "seed":u'種子下載',
    "relavance_url":u'相關鏈接',
    "filelist":u'文件列表',
    "tips":u'友情提示',
    "mail_tip":u'投訴郵箱：',
    "interest":u'大家對這些感興趣',
    "interest_text":u'你知道嗎？將本網頁分享給您的好友，能夠獲得更快的下載速度！',
    "video": u'視頻',
    "image": u'圖片',
    "document": u'文檔',
    "music": u'音樂',
    "package": u'壓縮包',
    "software": u'程序',
    "other":u'其他',
    "toptip1":u'總排行',
    "toptip2":u'月排行',
    "toptip3":u'周排行',
    "toptip4":u'日排行',
    "toptip5":u'最新收錄',
},
"EN":{
    "title":u'Ciliss - torrent search engine',
    "searchtxt":u'What movie do you wanna see?',
    "magurl":u'Torrent search',
    "headtip1":u'Torrent',
    "headtip2":u'Tags',
    "headtip3":u'Top',
    "foottip1":u'Mobile',
    "foottip2":u'Online Play',
    "foottip3":u'About',
    "sort_default":u'Default',
    "sort_time":u'Create Time',
    "sort_length":u'File Size',
    "sort_relavance":u'Relavance',
    "search":u'search',
    "create_time":u'Create Time:',
    "filelength":u'File Size:',
    "downloads":u'Hot:',
    "last_seen":u'Last Download:',
    "total_found":u'About',
    "about":u'About',
    "result":u'results',
    "time":u'Create Time',
    "lastdown":u'Last Download',
    "download_count":u'Hot',
    "files_size":u'File Size',
    "files":u'File Count',
    "filetype":u'File Type',
    "thunder":u'Thunder Link',
    "magnet":u'Magnet Link',
    "seed":u'Seed link',
    "relavance_url":u'Related links',
    "filelist":u'File Lists',
    "tips":u'TIPS',
    "mail_tip":u'Compain Email:',
    "interest":u'People are interested in',
    "interest_text":u'Do you know? Share this page to your friend, you can get a faster download speed!',
    "video": u'video',
    "image": u'image',
    "document": u'document',
    "music": u'music',
    "package": u'package',
    "software": u'software',
    "other":u'other',
    "toptip1":u'Total',
    "toptip2":u'Month',
    "toptip3":u'Week',
    "toptip4":u'Daily',
    "toptip5":u'New source',
},
"JP":{
    "title":u'Ciliss - 磁力の検索',
    "searchtxt":u'何の映画が見たいか?',
    "magurl":u'磁力の検索',
    "headtip1":u'磁力の検索',
    "headtip2":u'タグ',
    "headtip3":u'人気',
    "foottip1":u'モバイル',
    "foottip2":u'オンライン放送',
    "foottip3":u'について',
    "sort_default":u'デフォルト',
    "sort_time":u'創立時間',
    "sort_length":u'大きさ',
    "sort_relavance":u'関連',
    "search":u'検 索',
    "create_time":u'創立時間：',
    "filelength":u'ファイルの大きさ：',
    "downloads":u'人気：',
    "last_seen":u'最後のダウンロード：',
    "total_found":u'約',
    "about":u'条について',
    "result":u'の結果, これは、 ',
    "time":u'創立時間',
    "lastdown":u'最後のダウンロード',
    "download_count":u'人気',
    "files_size":u'ファイルの大きさ',
    "files":u'ファイルの数',
    "filetype":u'ファイルタイプ',
    "thunder":u'迅雷リンク',
    "magnet":u'磁力リンク',
    "seed":u'ダウンロード',
    "relavance_url":u'関連リンク',
    "filelist":u'ファイル一覧',
    "tips":u'ヒント',
    "mail_tip":u'苦情メール箱：',
    "interest":u'我々は、これらに興味を持っている',
    "interest_text":u'知ってますか？当ホームページをお友達にシェアする事で、さらに早い速度の早いダウンロードを得ることができます！',
    "video": u'ビデオ',
    "image": u'ピクチャ',
    "document": u'ドキュメント',
    "music": u'音楽',
    "package": u'アーカイブ',
    "software": u'プログラム',
    "other":u'不明なファイル',
    "toptip1":u'総ソート',
    "toptip2":u'月ソート',
    "toptip3":u'曜日ソート',
    "toptip4":u'日ソート',
    "toptip5":u'新しい収録',
},
"KR":{
    "title":u'Ciliss - 자력 검색',
    "searchtxt":u'당신은 영화를보고 싶은?',
    "magurl":u'자력 검색',
    "headtip1":u'자력 검색',
    "headtip2":u'탭',
    "headtip3":u'순위',
    "foottip1":u'이동 버전',
    "foottip2":u'재생',
    "foottip3":u'정보',
    "sort_default":u'기본 정렬',
    "sort_time":u'시간을 만들기',
    "sort_length":u'파일 용량',
    "sort_relavance":u'관련성',
    "search":u'검 색',
    "create_time":u'시간을 만들기：',
    "filelength":u'파일 용량：',
    "downloads":u'인기：',
    "last_seen":u'마지막 아래 載：',
    "total_found":u'약',
    "about":u'결과, 그것은',
    "result":u'밀리 초 소요',
    "time":u'시간을 만들기',
    "lastdown":u'마지막 아래 載',
    "download_count":u'인기',
    "files_size":u'파일 용량',
    "files":u'파일 수량',
    "filetype":u'파일 형식',
    "thunder":u'신뢰연결',
    "magnet":u'자력연결',
    "seed":u'피드 다운로드',
    "relavance_url":u'관련 링크',
    "filelist":u'파일 리스트',
    "tips":u'팁',
    "mail_tip":u'신고 우평함：',
    "interest":u'우리는이에 관심이 있습니다',
    "interest_text":u'당신은 아십니까? 본 웹사이트를 친구에게 공유히시면 더 빠른 다운로드 속도를 얻을 수 있습니다!',
    "video": u'비디오',
    "image": u'사진',
    "document": u'문서',
    "music": u'음악',
    "package": u'아카이브',
    "software": u'프로그램',
    "other":u'알 수없는 파일',
    "toptip1":u'순위',
    "toptip2":u'월 순위',
    "toptip3":u'주 순위',
    "toptip4":u'일 순위',
    "toptip5":u'최신 수록',
},
}
langselect={
    "CN":u'                  <option value="CN" >简体中文</option>',
    "EN":u'                  <option value="EN" >English</option>',
    "KR":u'                  <option value="KR" >한국어</option>',
    "JP":u'                  <option value="JP" >日本語</option>',
    "HK":u'                  <option value="HK" >繁體中文</option>',
}
@register.filter(needs_autoescape=True)
def smartcoffee(value, autoescape=True):
    '''Returns input wrapped in HTML <b></b> tags'''
    '''and also detects surrounding autoescape on filter (if any) and escapes '''
    if autoescape:
        value = escape(value)
    result = '<b>%s</b>' % value
    return mark_safe(result)

@register.filter()
def format_time(t):
    if type(t) is datetime.datetime:
        d = t
    else:
        d = datetime.datetime.strptime(t.split('.')[0], '%Y-%m-%dT%H:%M:%S')
    now = datetime.datetime.utcnow()
    dt = now - d
    if dt.days > 365:
        return mark_safe(u'<b>%s年前</b>' % (dt.days / 365))
    elif dt.days > 30:
        return mark_safe(u'<b>%s个月前</b>' % (dt.days/30))
    elif dt.days > 1:
        return mark_safe(u'<b>%s天前</b>' % dt.days)
    elif dt.days == 1:
        return mark_safe(u'<b>昨天</b>')
    elif dt.seconds > 3600:
        return mark_safe(u'<b>%s小时前</b>' % (dt.seconds/3600))
    return mark_safe(u'<b class="cpill blue-pill">%s分钟前</b>' % (dt.seconds/60))

@register.filter()
def format_time_en(t):
    if type(t) is datetime.datetime:
        d = t
    else:
        d = datetime.datetime.strptime(t.split('.')[0], '%Y-%m-%dT%H:%M:%S')
    now = datetime.datetime.utcnow()
    dt = now - d
    if dt.days > 365:
        return mark_safe(u'<b>%s Years ago</b>' % (dt.days / 365))
    elif dt.days > 30:
        return mark_safe(u'<b>%s Months ago</b>' % (dt.days/30))
    elif dt.days > 1:
        return mark_safe(u'<b>%s Days ago</b>' % dt.days)
    elif dt.days == 1:
        return mark_safe(u'<b>Yesterday</b>')
    elif dt.seconds > 3600:
        return mark_safe(u'<b>%s Hours ago</b>' % (dt.seconds/3600))
    return mark_safe(u'<b class="cpill blue-pill">%s Minutes ago</b>' % (dt.seconds/60))

@register.filter()
def format_time_kr(t):
    if type(t) is datetime.datetime:
        d = t
    else:
        d = datetime.datetime.strptime(t.split('.')[0], '%Y-%m-%dT%H:%M:%S')
    now = datetime.datetime.utcnow()
    dt = now - d
    if dt.days > 365:
        return mark_safe(u'<b>%s년 전</b>' % (dt.days / 365))
    elif dt.days > 30:
        return mark_safe(u'<b>%s개월 전</b>' % (dt.days/30))
    elif dt.days > 1:
        return mark_safe(u'<b>%s전 에</b>' % dt.days)
    elif dt.days == 1:
        return mark_safe(u'<b>어 제</b>')
    elif dt.seconds > 3600:
        return mark_safe(u'<b>%s시간 전에</b>' % (dt.seconds/3600))
    return mark_safe(u'<b class="cpill blue-pill">%s분 전</b>' % (dt.seconds/60))

@register.filter()
def format_time_jp(t):
    if type(t) is datetime.datetime:
        d = t
    else:
        d = datetime.datetime.strptime(t.split('.')[0], '%Y-%m-%dT%H:%M:%S')
    now = datetime.datetime.utcnow()
    dt = now - d
    if dt.days > 365:
        return mark_safe(u'<b>%s年前に</b>' % (dt.days / 365))
    elif dt.days > 30:
        return mark_safe(u'<b>%sヶ月前</b>' % (dt.days/30))
    elif dt.days > 1:
        return mark_safe(u'<b>%s日前に</b>' % dt.days)
    elif dt.days == 1:
        return mark_safe(u'<b>昨日</b>')
    elif dt.seconds > 3600:
        return mark_safe(u'<b>%s小時前</b>' % (dt.seconds/3600))
    return mark_safe(u'<b class="cpill blue-pill">%s分前</b>' % (dt.seconds/60))

@register.filter()
def format_time_hk(t):
    if type(t) is datetime.datetime:
        d = t
    else:
        d = datetime.datetime.strptime(t.split('.')[0], '%Y-%m-%dT%H:%M:%S')
    now = datetime.datetime.utcnow()
    dt = now - d
    if dt.days > 365:
        return mark_safe(u'<b>%s年前</b>' % (dt.days / 365))
    elif dt.days > 30:
        return mark_safe(u'<b>%s個月前</b>' % (dt.days/30))
    elif dt.days > 1:
        return mark_safe(u'<b>%s日前</b>' % dt.days)
    elif dt.days == 1:
        return mark_safe(u'<b>昨日</b>')
    elif dt.seconds > 3600:
        return mark_safe(u'<b>%s小時前</b>' % (dt.seconds/3600))
    return mark_safe(u'<b class="cpill blue-pill">%s分鐘前</b>' % (dt.seconds/60))

@register.filter()
def highlight(title, words):
    try:
        for w in words:
            title = re.sub(w, '<b>%s</b>' % w, title)
    except:
        pass
    return mark_safe(title)

@register.filter()
def thunder_url(t):
    td='AA'+t+'ZZ'
    thunder="thunder://"+b64encode(td)
    return mark_safe(thunder)
@register.filter()
def file_cat_name(t):
    cn=workers.metautils.get_label(t)
    return mark_safe(cn)

@register.filter()
def lang_format(ltype, txt):
    dType = lang.get(ltype,{})
    sDesc = dType.get(txt,'')
    return mark_safe(sDesc)


@register.filter()
def lang_select(sLang):
    sDesc=""
    word='"'+sLang+'"'
    for k in langselect:
        if langselect[k].find(sLang)>0:
            sTitle = re.sub(word,'"%s" selected' % sLang,langselect[k])
            sDesc+=sTitle+'\n'
        else:
            sDesc+=langselect[k]+'\n'
    return mark_safe(sDesc)
