# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('search', '0010_auto_20151019_1418'),
    ]

    operations = [
        migrations.AlterField(
            model_name='hash',
            name='classified',
            field=models.BooleanField(default=False, verbose_name=b'\xe6\x98\xaf\xe5\x90\xa6\xe5\xb1\x8f\xe8\x94\xbd'),
        ),
    ]
