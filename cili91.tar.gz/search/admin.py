from django.contrib import admin
from search.models import Hash, FileList, StatusReport, RecKeywords
from dmca.models import Hashlog
from top.models import HashLog, KeywordLog, Newkey, Newhash


# Register your models here.
admin.site.register(Hash)
admin.site.register(FileList)
admin.site.register(StatusReport)
admin.site.register(RecKeywords)
admin.site.register(Hashlog)
admin.site.register(HashLog)
admin.site.register(KeywordLog)
admin.site.register(Newkey)
admin.site.register(Newhash)
