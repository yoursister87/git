# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [ 
    ]   

    operations = [ 
        migrations.CreateModel(
            name='Hashlog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('log_time', models.DateTimeField(auto_now_add=True, db_index=True)),
		('info_hash', models.CharField(max_length=40)),
		('ip', models.CharField(max_length=30)),
            ],  
        ),  
    ]
