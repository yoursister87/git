import datetime
from django.db.models.aggregates import Count
from django.db import models
from django.utils import timezone

# Create your models here.

class Hashlog(models.Model): 
    log_time = models.DateTimeField(auto_now_add=True, db_index=True)
    info_hash  = models.CharField(max_length=40)
    ip = models.CharField(max_length=30)
    def __unicode__(self):
        return self.info_hash
