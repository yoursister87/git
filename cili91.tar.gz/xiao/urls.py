"""bthome URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import include, url
from django.contrib import admin

import web.views

urlpatterns = [
    url(r'^top/', include('top.urls')),
#    url(r'^api/', include('search.urls')),
    url(r'^$', web.views.index, name='index'),
    url(r'^index.html$', web.views.index, name='index'),
    url(r'^rm_maglink/(.{40})$', web.views.rm_maglink,name='rm_maglink'),
#    url(r'^rm_maglink/(.{40})$', web.views.rm_maglink),
    url(r'^tags/$', web.views.tags, name='tags'),
    url(r'^tags/(\d{1,10})$', web.views.tags, name='tags'),
    url(r'^info/(\d{1,10}).html$', web.views.hash, name='hash'),
    url(r'^(.{40}).html$', web.views.hash_old),
    url(r'^wiki/(.{40}).html$', web.views.hash, name='wiki'),
    url(r'^cililianjie/(.{40}).html$', web.views.hash_old),
    url(r'^hash/(.{40})$', web.views.hash_old),
    url(r'^hash/(.{40}).html$', web.views.hash),
    url(r'^info/(.{40})$', web.views.hash_old),
    url(r'^search/(.*?)_ctime_(\d{1,10}).html$', web.views.search),
    url(r'^search/(.*?)_click_(\d{1,10}).html$', web.views.search),
    url(r'^search/(.*?)_length_(\d{1,10}).html$', web.views.search),
    url(r'^search/(.*?)/(\d*).html$', web.views.search, name='list'),
    url(r'^search/(.*?).html$', web.views.search),
    url(r'^search/(.*?)$', web.views.search),
    url(r'^list/(.+?)/(\d*)$', web.views.search_old),
#    url(r'^online/$', web.views.play, name='play'),
#    url(r'^mobile/$', web.views.mobile, name='mobile'),
#    url(r'^about/$', web.views.about, name='about'),
#    url(r'^xunlei/$', web.views.xunlei, name='xunlei'),
    url(r'^code/$', web.views.code, name='code'),
    url(r'^rss/(.+?).xml$', web.views.rss, name='list'),
    url(r'^map/(.+?).xml$', web.views.map, name='list'),
    url(r'^siteadmin/', include(admin.site.urls)),
]

