#!/usr/bin/sh
systemctl stop firewalld.service 
systemctl disable firewalld.service
systemctl stop iptables.service
systemctl disable iptables.service
yum  install unzip
yum  install gcc gcc-c++ python-devel mariadb mariadb-devel mariadb-server
