import base64
import urllib2
  
def magnet_to_torrent(src_url):
  url = src_url[20:]
  tmp_url = url.upper()
  real_url = 'http://dl.btbook.co/'+tmp_url[0:2]+'/'+tmp_url[len(tmp_url)-2:]+'/'+tmp_url+'.torrent'
  return real_url
  
def Url2Thunder(url):
  url='AA'+url+'ZZ'
  url = base64.b64encode(url)  
  url = 'thunder://' + url
  return url
