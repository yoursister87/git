#!/usr/bin/sh
ps -aux |grep simdht_worker |awk '{print $2}' |xargs kill -9
ps -aux |grep index_worker |awk '{if($8 == "Sl") print $2}' |xargs kill -9
