#!/bin/sh
nohup python simdht_worker.py >/dev/zero &
nohup python index_worker.py >/dev/zero & 

