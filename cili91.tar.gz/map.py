import time
id_ = 1
uptime = time.strftime("%Y-%m-%d", time.localtime())
print uptime
f = open('./www/sitemap/map%s.xml' % id_, 'w')
f2 = open('./www/sitemap.xml', 'w')
f2.write('<sitemapindex>\n<sitemap>\n<loc>http://www.soso1024.com/sitemap/map1.xml</loc>\n</sitemap>\n')
for i, line in enumerate(open('./www/map.csv')):
        if i % 10000==0:
                print str("map") + str(i/10000+1) + str(".xml") + str("    is ok!")
                f.write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n')

        f.write('''<url>
<loc>http://www.soso1024.com/wiki/%s.html</loc>
<lastmod>%s</lastmod>
<priority>0.8</priority>
</url>
''' % (line.rstrip(),uptime))
        if i % 10000==9999:
                f.write('</urlset>')
                f.close()
                id_ += 1
                f = open('./www/sitemap/map%s.xml' % id_, 'w')
                f2.write('''<sitemap>
<loc>http://www.soso1024.com/sitemap/map%s.xml</loc>
</sitemap>
''' % id_)
f2.write('</sitemapindex>')
f2.close()
f.write('</urlset>')
f.close()
