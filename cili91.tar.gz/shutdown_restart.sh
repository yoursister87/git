#!/bin/sh
systemctl start mariadb.service
indexer -c sphinx.conf --all
searchd --config ./sphinx.conf
supervisord -c /etc/supervisord.conf
supervisorctl start all
/usr/sbin/nginx
