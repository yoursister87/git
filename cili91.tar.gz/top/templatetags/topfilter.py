#coding: utf8
from django import template
from django.utils.safestring import mark_safe
from search.models import Hash

register = template.Library()

@register.filter()
def hash_name(t):
    if len(t) == 40:
        h = Hash.objects.filter(info_hash=t).first()
    else:
        h = Hash.objects.filter(id=t).first()
    if h:
        return h.name
    return t

