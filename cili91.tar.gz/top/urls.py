from django.conf.urls import include, url

urlpatterns = [
#    url(r'^json_log$', 'top.views.json_log', name='top_log'),
#    url(r'^json_newkey$', 'top.views.json_newkey', name='top_newkey'),
    url(r'^$', 'top.views.index', name='top_index'),
    url(r'^month$', 'top.views.months', name='top_month'),
    url(r'^week$', 'top.views.weeks', name='top_week'),
    #url(r'^all$', 'top.views.all', name='top_all'),
    url(r'^new$', 'top.views.new', name='top_new'),
]


