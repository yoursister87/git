import time
import datetime
from django.shortcuts import render
from django.views.decorators.cache import cache_page
from django.http.response import HttpResponse
from .models import KeywordLog, HashLog, Newkey, Newhash
from search.models import Hash

# Create your views here.


#@cache_page(600)
def index(request):
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d = {
        'top_hash_daily': Newhash.objects.top_daily(),
        'lang':lang,
    }
    return render(request, 'top.html', d)

#@cache_page(600)
def months(request):
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d = {
        'top_hash_months': Newhash.objects.top_months(),
        'lang':lang,
    }
    return render(request, 'month.html', d)


#@cache_page(600)
def weeks(request):
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d = {
        'top_hash_weeks': Newhash.objects.top_weeks(),
        'lang':lang,
    }
    return render(request, 'week.html', d)
	
	
@cache_page(600)
def all(request):
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d = {
        'top_hash_all': Newhash.objects.top_all(),
        'lang':lang,
    }
    return render(request, 'all.html', d)


#@cache_page(600)
def new(request):
    if request.META.has_key('HTTP_ACCEPT_LANGUAGE'):
         xclang = request.META['HTTP_ACCEPT_LANGUAGE']
         clang = xclang.upper()
         if 'CN' in clang:
              lang=""
              lang=request.COOKIES.get("lang","CN")
         elif 'HK' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'TW' in clang:
              lang=""
              lang=request.COOKIES.get("lang","HK")
         elif 'JA' in clang:
              lang=""
              lang=request.COOKIES.get("lang","JP")
         elif 'KO' in clang:
              lang=""
              lang=request.COOKIES.get("lang","KR")
         else:
              lang=""
              lang=request.COOKIES.get("lang","EN")
    else:
         clang="unknow"
         lang=""
         lang=request.COOKIES.get("lang","CN")
    d = {
        'top_hash_new': Hash.objects.order_by('-id')[:100],
        'lang':lang,
    }
    return render(request, 'new.html', d)


def json_log(request):
    log_type = request.GET.get('type')
    ip = request.META.get('HTTP_X_FORWARDED_FOR')
    if not ip:
        ip = request.META.get('HTTP_X_REAL_IP', '')
    if log_type == 'keyword':
        keyword = request.GET['keyword'].strip()[:100]
        KeywordLog.objects.create(keyword=keyword, ip=ip)
    elif log_type == 'hash':
        try:
            hash_id = int(request.GET['hash'])
        except ValueError:
            return HttpResponse('invalid')
        HashLog.objects.create(hash_id=hash_id, ip=ip)
    return HttpResponse('ok')

def json_newkey(request):
    utcnow = datetime.datetime.utcnow()
    log_type = request.GET.get('type')
    if log_type == 'keyword':
      keyword = request.GET['keyword'].strip()[:100]
      if keyword != "":
	oldkeyword = Newkey.objects.filter(keyword__iexact=keyword).values()
	if oldkeyword:
           Newkey.objects.filter(keyword=keyword).update(log_time=utcnow)
	else:
           Newkey.objects.create(keyword=keyword)
    elif log_type == 'hash':
        try:
            hash_id = int(request.GET['hash'])
        except ValueError:
            return HttpResponse('invalid')
        HashLog.objects.create(hash_id=hash_id, ip=ip)
    return HttpResponse('ok')
