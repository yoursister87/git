# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('top', '0003_auto_20151007_0634'),
    ]

    operations = [
        migrations.AlterField(
            model_name='newhash',
            name='log_time',
            field=models.DateTimeField(auto_now_add=True, db_index=True),
        ),
        migrations.AlterField(
            model_name='newkey',
            name='keyword',
            field=models.CharField(unique=True, max_length=100),
        ),
        migrations.AlterField(
            model_name='newkey',
            name='log_time',
            field=models.DateTimeField(auto_now_add=True, db_index=True),
        ),
    ]
