# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='HashLog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('log_time', models.DateTimeField(auto_now_add=True)),
                ('hash_id', models.PositiveIntegerField()),
                ('ip', models.CharField(max_length=30)),
            ],
        ),
        migrations.CreateModel(
            name='KeywordLog',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('log_time', models.DateTimeField(auto_now_add=True)),
                ('keyword', models.CharField(max_length=100)),
                ('ip', models.CharField(max_length=30)),
            ],
        ),
        migrations.CreateModel(
            name='Newhash',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('log_time', models.DateTimeField(auto_now_add=True)),
                ('info_hash', models.CharField(max_length=40)),
                ('ip', models.CharField(max_length=30)),
            ],  
        ),
        migrations.CreateModel(
            name='Newkey',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('keyword', models.CharField(max_length=100)),
                ('log_time', models.DateTimeField(auto_now_add=True)),
            ],  
        ),
    ]
